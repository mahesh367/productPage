package com.example.Order.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Order.model.Order;

public interface OrderRepository extends JpaRepository<Order,Long>{

}
