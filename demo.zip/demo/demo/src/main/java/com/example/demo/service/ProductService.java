package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.ProductRepository;
import com.example.demo.model.Product;

@Service
public class ProductService {
	
	@Autowired
	public ProductRepository productrepository;
	
	public List<Product> getAllProducts(){
		
		return productrepository.findAll();
	}

}
